// Omar Porte

public class TrieNode<T> {
    private T data;
    private TrieNode<T>[] children;

    /** Initializes data to null and the children array to a null array with 26 spaces. */
    public TrieNode() {
        this.data = null;
        this.children = new TrieNode[26];
    }

    /** Gets the data. */
    public T getData() {
        return data;
    }

    /** Sets the data. */
    public void setData(T data) {
        this.data = data;
    }

    /** Returns the TrieNode<T> associated with the given char. */
    public TrieNode<T> getChild(char letter){
        int i = (int) (letter - 'a');

        if (!Character.isAlphabetic(letter) || Character.isUpperCase(letter)){
            return null;
        }else if (children[i] == null){
            children[i] = new TrieNode<>();
            return children[i];
        }
        return children[i];
    }

    /** Returns the number of nodes in the tree. */
    public int getTreeSize(){
        int size = 1;
        for (int i = 0; i < children.length; i++){
            if(children[i] != null){
                size += children[i].getTreeSize();
            }
        }
        return size;
    }
}
