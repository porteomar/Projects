//Omar Porte

public class Trie<T> {
    private TrieNode<T> root;

    /** Initializes root to a new node. */
    public Trie() {
        this.root = new TrieNode<>();
    }

    /** Takes in a String and returns the appropriate trieNode*/
    private TrieNode<T> getNode(String word){
        TrieNode<T> trieNode = root;

        for (int i = 0; i < word.length(); i++){
            trieNode = trieNode.getChild(word.charAt(i));
        }
        return trieNode;
    }

    /** Gets the data currently stored on the TrieNode associated with the input String. */
    public T get(String string) {

        return getNode(string).getData();
    }

    /** Sets the data currently stored on the TrieNode Associated with the input String to the T val provided*/
    public T put(String string, T tVal){
        getNode(string).setData(tVal);
        return getNode(string).getData();
    }

    /** Used for testing and returns the root node. */
    public TrieNode<T> getRoot(){
        return root;
    }

}
