// Omar Porte

import java.util.Arrays;
import java.util.Random;

public class CharBag{
    private int size;
    private int[] charCount;

    /** Creates and empty CharBag. */
    public CharBag() {
        this.charCount = new int[27];
        this.size = 0;
    }

    /** Converts a char to an int. */
    private int helper(char c){
        int i = (int) (c - 'a');
        if(c == '.'){
            i = 26;
        }
        return i;
    }

    /** Adds a char to the bag. */
    public void add(char c) {

        if (Character.isAlphabetic(c) == false){
            c = '.';
        }
        if (Character.isUpperCase(c)){
            c = Character.toLowerCase(c);
        }
        for(int i = 0; i < charCount.length; i++){
            if (i == helper(c)){
                charCount[i] += 1;
            }
        }
        size++;
    }

    /** Removes a char from the CharBag. */
    public void remove(char c){

        if (Character.isAlphabetic(c) == false){
            c = '.';
        }
        if (Character.isUpperCase(c)){
            c = Character.toLowerCase(c);
        }
        for(int i = 0; i < charCount.length; i++){
            if (i == helper(c)){
                if(charCount[i] > 0){
                    charCount[i] -= 1;
                    size--;
                }
            }
        }
    }

    /** Gets how many times a given char is in the CharBag.*/
    public int getCount(char c){
        int count = 0;
        if (Character.isAlphabetic(c) == false){
            c = '.';
        }
        if (Character.isUpperCase(c)){
            c = Character.toLowerCase(c);
        }

        for (int i = 0; i < charCount.length; i++){
            if(i == helper(c)){
                count = charCount[i];
            }
        }
        return count;
    }

    /** Returns the total size of the CharBag. */
    public int getSize(){
        return size;
    }

    /** Returns a randomly chosen char from the chars in the CharBag. */
    public char getRandomChar(){

        if(size == 0){
            return '.';
        }else{
            int random = new Random().nextInt(size);

            for (int j = 0; j < charCount.length - 1; j++) {
                random -= charCount[j];

                 if (random < 0) {
                    return (char) (j + 'a');
                }
            }
            return '.';
        }
    }

    /** Prints the the number of each char in the bag in the format of "CharBag{a:#, ... , .:#}"*/
    @Override
    public String toString() {
        return "CharBag{" + "a:" + Arrays.toString(charCount).charAt(1) + ", " +
                "b:" + Arrays.toString(charCount).charAt(4) + ", " +
                "c:" + Arrays.toString(charCount).charAt(7) + ", " +
                "d:" + Arrays.toString(charCount).charAt(10) + ", " +
                "e:" + Arrays.toString(charCount).charAt(13) + ", " +
                "f:" + Arrays.toString(charCount).charAt(16) + ", " +
                "g:" + Arrays.toString(charCount).charAt(19) + ", " +
                "h:" + Arrays.toString(charCount).charAt(22) + ", " +
                "i:" + Arrays.toString(charCount).charAt(25) + ", " +
                "j:" + Arrays.toString(charCount).charAt(28) + ", " +
                "k:" + Arrays.toString(charCount).charAt(31) + ", " +
                "l:" + Arrays.toString(charCount).charAt(34) + ", " +
                "m:" + Arrays.toString(charCount).charAt(37) + ", " +
                "n:" + Arrays.toString(charCount).charAt(40) + ", " +
                "o:" + Arrays.toString(charCount).charAt(43) + ", " +
                "p:" + Arrays.toString(charCount).charAt(46) + ", " +
                "q:" + Arrays.toString(charCount).charAt(49) + ", " +
                "r:" + Arrays.toString(charCount).charAt(52) + ", " +
                "s:" + Arrays.toString(charCount).charAt(55) + ", " +
                "t:" + Arrays.toString(charCount).charAt(58) + ", " +
                "u:" + Arrays.toString(charCount).charAt(61) + ", " +
                "v:" + Arrays.toString(charCount).charAt(64) + ", " +
                "w:" + Arrays.toString(charCount).charAt(67) + ", " +
                "x:" + Arrays.toString(charCount).charAt(70) + ", " +
                "y:" + Arrays.toString(charCount).charAt(73) + ", " +
                "z:" + Arrays.toString(charCount).charAt(76) + ", " +
                ".:" + Arrays.toString(charCount).charAt(79) + '}';
    }

}

