public class EncryptUtils {

    public static String[]  encryptMany(BaseCipher cipher, String[] arrayOfStrings){
        String[] newArray = new String[arrayOfStrings.length];

        for (int i = 0; i < arrayOfStrings.length; i++){
            newArray[i] = cipher.encrypt(arrayOfStrings[i]);
        }
    return newArray;
    }

    public static String[] decryptMany(BaseCipher cipher, String[] arrayOfStrings){
        String[] newArray = new String[arrayOfStrings.length];

        for (int i = 0; i < arrayOfStrings.length; i++){
            newArray[i] = cipher.decrypt(arrayOfStrings[i]);
        }
    return newArray;
    }
}
