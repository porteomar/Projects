public class WordReplacementCipher extends BaseCipher {
    private String wordToReplaceTo;
    private String wordToReplaceFrom;

    public WordReplacementCipher(String wordToReplaceTo, String wordToReplaceFrom) {
        super("WordReplacementCipher(" + wordToReplaceTo + ", " + wordToReplaceFrom + ')');
        this.wordToReplaceTo = wordToReplaceTo;
        this.wordToReplaceFrom = wordToReplaceFrom;

    }

    public String encrypt(String replacement){
        replacement = replacement.replace(wordToReplaceTo, wordToReplaceFrom);

        return replacement;
    }

    public String decrypt(String reverse){
        reverse = reverse.replace(wordToReplaceFrom, wordToReplaceTo);

        return reverse;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        } else if (other == null) {
            return false;
        } else if (other instanceof WordReplacementCipher) {
            WordReplacementCipher wordReplacement = (WordReplacementCipher) other;
            return wordReplacement.wordToReplaceFrom.equals(this.wordToReplaceFrom) && wordReplacement.wordToReplaceTo.equals(this.wordToReplaceTo);
        } else {
            return false;
        }
    }

   // public static void main(String[] args){
     //   WordReplacementCipher k = new WordReplacementCipher("be", "ga");
       // System.out.println(k.encrypt("gara"));
        //System.out.println(k.decrypt(k.encrypt("gara")));
    //}
}