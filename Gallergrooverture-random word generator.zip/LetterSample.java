//Omar Porte

public class LetterSample {
    private String stringSegment;
    private char nextLetter;
    public static final char STOP = '.';

    /** Constructor that takes a val for the segment string and the nextLetter char. */
    public LetterSample(String shortString, char nextLetter) {
        this.stringSegment = shortString;
        this.nextLetter = nextLetter;
    }

    /** Gets the segment String for the obj. */
    public String getSegment() {
        return stringSegment;
    }

    /** Gets the next letter for this obj. */
    public char getNextLetter() {
        return nextLetter;
    }

    /** Takes a String and generates letter samples with it. */
    public static LetterSample[] toSamples(String input, int segmentSize) {
        String word = "";


        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if(Character.isLetter(c)){
                if (Character.isUpperCase(c)) {
                    c = Character.toLowerCase(input.charAt(i));
                }
                word += c;
            }
        }
        word += STOP;
        LetterSample[] segmentArray = new LetterSample[word.length()];
        LetterSample segment;

        for(int i = 0; i < word.length(); i++){

            if (  i > segmentSize) {
                segment = new LetterSample( word.substring(i - segmentSize , i), word.charAt(i));
                segmentArray[i] = segment;
            } else{
                segment = new LetterSample(word.substring(0, i), word.charAt(i));
                segmentArray[i] = segment;
            }
        }
        return segmentArray;
    }

    /** Generates output in the format ""segment" -> nextLetter " .*/
    public String toString() {
        return "\"" + stringSegment + "\"" +  " -> "  + nextLetter;
    }

}
