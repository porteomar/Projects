public class EvenOddCipher extends BaseCipher{
    private String stringToEncrypt;
    private String stringToDecrypt;

    public EvenOddCipher(){
        super("EvenOddCipher");
        stringToDecrypt = "No String";
        stringToEncrypt = "No String";
    }

    public String encrypt(String stringToEncrypt) {
        String encrypted = "";
        String even = "";
        String odd = "";

        for (int i = 0; i < (stringToEncrypt.length()); i++) {
            if (i % 2 == 0) {
                even += stringToEncrypt.charAt(i);
            } else {
                odd += stringToEncrypt.charAt(i);
            }
        }
        return encrypted = even + odd;
    }

    public String decrypt(String stringToDecrypt) {
        String decrypted = "";
        String firstHalf = "";
        String secondHalf = "";
        int half = (int) Math.ceil((stringToDecrypt.length() / 2.0));

        for (int i = 0; i < half; i++) {
            firstHalf += stringToDecrypt.charAt(i);
        }
        for (int j = half; j < (stringToDecrypt.length()); j++) {
            secondHalf += stringToDecrypt.charAt(j);
        }

        while (firstHalf.length() != 0 || secondHalf.length() != 0) {
            if (firstHalf.length() != 0) {
                decrypted += firstHalf.charAt(0);
                firstHalf = firstHalf.substring(1);
            }
            if (secondHalf.length() != 0) {
                decrypted += secondHalf.charAt(0);
                secondHalf = secondHalf.substring(1);
            }
        }

        return decrypted;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        } else if (other == null) {
            return false;
        } else if (other instanceof EvenOddCipher) {
            EvenOddCipher evenOdd = (EvenOddCipher) other;
            return evenOdd.stringToEncrypt.equals(this.stringToEncrypt) && evenOdd.stringToDecrypt.equals(this.stringToDecrypt);
        } else {
            return false;
        }
    }
    // public static void main(String[] args){
    //     EvenOddCipher k = new EvenOddCipher();
    //     System.out.println(k.encrypt("hello friend"));
    //     System.out.println((k.decrypt(k.encrypt("hello friend"))));
    // }
}
