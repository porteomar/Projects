//Omar Porte

public class Gibberisher {
    private Trie<CharBag> model;
    private int segmentLength;
    private int numLetterSamples;

    /** Takes the value of the segment length and initializes the TrieNode and sample count variables. */
    public Gibberisher(int segmentLength) {
        this.segmentLength = segmentLength;
        this.model = new Trie<CharBag>();
        this.numLetterSamples = 0;
    }

    /** Adds one sample into the model. */
    public void train(LetterSample sample) {
        String key = sample.getSegment();

        if (model.get(key) == null) {
            CharBag newBag = new CharBag();
            newBag.add(sample.getNextLetter());
            model.put(sample.getSegment(), newBag);
        } else {
            model.get(key).add(sample.getNextLetter());
        }
    }

    /** Uses the LetterSample class to generate LetterSamples then uses the preceding function to train the model for
     * for each LetterSample. */
    public void train(String string) {
        LetterSample[] samples = LetterSample.toSamples(string, segmentLength);

        for (LetterSample sample : samples) {
            train(sample);
            numLetterSamples++;
        }
    }

    /** Calls the preceding method for each word in the array. */
    public void train(String[] stringArray) {
        for (String string : stringArray) {
            train(string);
        }
    }

    /** Gets the number of samples used so far to train the model. */
    public int getSampleCount() {
        return numLetterSamples;
    }

    /** Generates a String. */
    public String generate() {
        String word = "";

        while (word.endsWith(".") != true ){
            System.out.println(word);
            //String sample = word.substring(Math.max(0, word.length() - numLetterSamples), Math.max(0, word.length() - 1));
            int start_index = Math.max(0, word.length() - segmentLength);
            String sample = word.substring(start_index);
            CharBag bag = model.get(sample);
            System.out.println(start_index);
            System.out.println(sample);
            System.out.println(bag);
            word += bag.getRandomChar();
        }
        return word.substring(0, word.length() - 1);
    }
}