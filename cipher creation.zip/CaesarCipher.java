// Omar Porte porte657

public class CaesarCipher extends BaseCipher{
    private int key;

    public CaesarCipher(int key){
       super("Caesar(" + key + ")");
        this.key = key;
    }

    public boolean isValid(){
        if (key > 25 || key < 1){
            return false;
        }
        return true;
    }

    private char rotate(char letter, int key){
        int i = (int)( letter - 'a');

        i += key;
        i %= 26;
        if(i < 0){
            i += 26;
        }
        return (char)(i + 'a');
    }

    public String encrypt(String messageToEncrypt){
        String output = "";
        for(int i = 0; i < messageToEncrypt.length(); i++ ){
            if(Character.isUpperCase(messageToEncrypt.charAt(i))){
                char c = Character.toLowerCase(messageToEncrypt.charAt(i));

                output += rotate(c, key);
            }
            else if (messageToEncrypt.charAt(i) == ' ' || messageToEncrypt.charAt(i) == '.' || messageToEncrypt.charAt(i) == ',' ||
                    messageToEncrypt.charAt(i) == '!'){
                output += messageToEncrypt.charAt(i);
            }
            else {
                output += rotate(messageToEncrypt.charAt(i), key);
            }
        }
        return output;
    }
    public String decrypt(String messageToDecrypt){
        String output = "";
        for(int i = 0; i < messageToDecrypt.length(); i++ ){
            if(Character.isUpperCase(messageToDecrypt.charAt(i))){
                char c = Character.toLowerCase(messageToDecrypt.charAt(i));

                output += rotate(c, (-key));
            }
            else if (messageToDecrypt.charAt(i) == ' ' || messageToDecrypt.charAt(i) == '.' || messageToDecrypt.charAt(i) == ',' ||
                    messageToDecrypt.charAt(i) == '!' || messageToDecrypt.charAt(i) == '\''){
                output += messageToDecrypt.charAt(i);
            }
            else {
                output += rotate(messageToDecrypt.charAt(i), (-key));
            }
        }
        return output;
    }
    public boolean equals(Object other){
        if(other == this){
            return true;
        }
        else if(other == null){
            return false;
        }
        else if(other instanceof CaesarCipher){
            CaesarCipher cipher = (CaesarCipher) other;
            return cipher.key == this.key;
        }
        else {
            return false;
        }
    }
    public static void main(String[] args){
        CaesarCipher c1 = new CaesarCipher(1);
        System.out.println(c1 instanceof BaseCipher); // true
//        // the following code should compile and run correctly.
        BaseCipher bc = c1;
        System.out.println(bc.encrypt("abc-xyz")); // bcd-yza
    }
}

