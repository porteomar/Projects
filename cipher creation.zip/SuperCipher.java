public class SuperCipher extends BaseCipher {
    private BaseCipher[] arrayOfCiphers;

    public SuperCipher(BaseCipher[] arrayOfCiphers) {
        super("BaseCipher");
        this.arrayOfCiphers = arrayOfCiphers;
    }

    @Override
    public boolean isValid() {
        for (int i = 0; i < arrayOfCiphers.length; i++) {
            if (!arrayOfCiphers[i].isValid()) {
                return false;
            }
        }
    return true;
    }

    @Override
    public String encrypt(String stringToEncrypt){

        for(int i = 0; i < (arrayOfCiphers.length); i++){
           stringToEncrypt = arrayOfCiphers[i].encrypt(stringToEncrypt);
        }
        return stringToEncrypt;
    }

    @Override
    public String decrypt(String stringToDecrypt){

        for(int i = (arrayOfCiphers.length - 1); i >= 0; i--){
            stringToDecrypt = arrayOfCiphers[i].decrypt(stringToDecrypt);
        }
        return stringToDecrypt;
    }

    @Override
    public String toString(){
        String output = "SuperCipher(";
        for(int i = 0; i < arrayOfCiphers.length; i++){
            if(arrayOfCiphers.length == 1) {
                output += arrayOfCiphers[i].toString();
            }
            else{
                output += ( arrayOfCiphers[i].toString() + " | " );
            }
        }
        return output + ')';
    }

    @Override
    public boolean equals(Object other){
        if(other == this){
            return true;
        }
        else if(other == null){
            return false;
        }
        else if(other instanceof SuperCipher){
            SuperCipher superCipher = (SuperCipher) other;
            return superCipher.arrayOfCiphers == this.arrayOfCiphers;
        }
        else {
            return false;
        }
    }
}
